public interface TotalEnergy {
    double calculate(MCSimulation.LatticeParametersImpl latticeParametersImpl, double currentResult);
}
