Marcin Chamera:
- implementacja executeMCSteps i użytych tam metod pomocniczych
- testy i sprawdzenie poprawności działania
- refaktoryzacja

Dariusz Dyrga:
- implementacja setLattice, setEnergyParameters, setProbablityFormula, setTkB, getState
- pola klasy MCSimulation
- implementacja klasy LatticeParametersImpl
